import React, { useEffect } from "react";
import { MDBDataTable } from "mdbreact";
import { FaRegEye } from "react-icons/fa6";
import Loader from "../layouts/Loader";
import { useAlert } from "react-alert";
import { useDispatch, useSelector } from "react-redux";
import { clearErrors, myOrder } from "../../action/orderAction";
import { getRestaurants } from "../../action/restaurantAction";
const ListOrders = () => {
  const alert = useAlert();
  const dispatch = useDispatch();

  const { loading, error, orders } = useSelector((state) => state.myOrders);
  const restaurants = useSelector((state) => state.restaurants);

  const restaurantList = Array.isArray(restaurants.restaurants)
    ? restaurants.restaurants
    : [];
  useEffect(() => {
    dispatch(myOrder());
    dispatch(getRestaurants());
    if (error) {
      alert.error(error);
      dispatch(clearErrors);
    }
  }, [dispatch, alert, error]);

  const setOrders = () => {
    const data = {
      columns: [
        {
          label: "Restaurants Name",
          field: "restaurant",
          sort: "asc",
        },
        {
          label: "Orders Item",
          field: "orderItems",
          sort: "asc",
        },
        {
          label: "Num of Items",
          field: "numOfItems",
          sort: "asc",
        },
        {
          label: "Amount",
          field: "amount",
          sort: "asc",
        },
        {
          label: "Order Date",
          field: "orderDate",
          sort: "asc",
        },
        {
          lable: "Actions",
          field: "actions",
          sort: "asc",
        },
      ],
      rows: [],
    };
    if (orders && orders.length > 0 && restaurantList.length > 0) {
      const sortOrders = orders.sort(
        (a, b) => new Date(b.createdAt) - new Date(a.createdAt)
      );
      sortOrders.forEach((order) => {
        const ordersItemNames = order.orderItems
          .map((item) => item.name)
          .join(",");
      });
    }
  };
  return (
    <>
      <div className="cartt">
        <h1 className="my-5">My Orders</h1>

        {5 > 10 ? (
          <Loader />
        ) : (
          // <MDBDataTable data="" className="px-3" bordered striped hover />
          <p>Your Order Details</p>
        )}
      </div>
    </>
  );
};

export default ListOrders;
